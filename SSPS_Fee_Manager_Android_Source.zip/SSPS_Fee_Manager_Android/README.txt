SRI SAIRAM PUBLIC SCHOOL - Fee Manager Android project

BUILD APK:
1. Install Android Studio on a computer.
2. Open this folder (SSPS_Fee_Manager_Android) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output is normally app/build/outputs/apk/debug/app-debug.apk.

FEATURES:
- Admin password login (configured as requested; SHA-256 hash stored in app assets)
- Student registration and local records
- Fee collection and printable receipt
- WhatsApp reminder (opens WhatsApp with a prepared message; admin taps Send)
- Daily attendance
- School payment QR image supplied by the school
- CSV report and JSON backup/restore

IMPORTANT:
- This is an offline, single-device starter app. Records stay in this device's app WebView storage.
- Export backups regularly. Clearing app data or uninstalling can erase records.
- UPI QR is displayed from the image provided. Confirm successful receipt in the bank/UPI app before marking a fee paid.
- Admin password in an offline APK is a basic access gate, not strong security against a technically skilled person. Do not reuse it for banking or other accounts.
- WhatsApp messages are not sent automatically; Android opens WhatsApp and the admin must send.
